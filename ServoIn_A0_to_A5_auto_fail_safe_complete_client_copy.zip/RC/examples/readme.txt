About these examples

These examples are to demonstrate how to use each class, not to provide a fully working program. The png files distributed with each example show how to wire certain components to the Arduino board. The fzz file is a Fritzing project file (fritzing.org) which is the source of the png files.